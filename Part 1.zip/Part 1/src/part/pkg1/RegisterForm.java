package part.pkg1;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.HashMap;
import java.util.regex.Pattern;

public class RegisterForm extends JFrame {

    // Shared user database (username -> password)
    public static HashMap<String, String> userDatabase = new HashMap<>();

    private final JTextField firstNameField;
    private final JTextField lastNameField;
    private final JTextField userTextField;
    private final JPasswordField passwordField;
    private final JPasswordField confirmPasswordField;
    private final JTextField phoneField;
    private final JButton registerButton;
    private final JLabel messageLabel;

    public RegisterForm() {
        setTitle("Register Form");
        setSize(500, 380);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(null);

        // First Name
        JLabel firstNameLabel = new JLabel("First Name:");
        firstNameLabel.setBounds(50, 30, 120, 25);
        firstNameLabel.setForeground(new Color(0, 102, 204));
        add(firstNameLabel);

        firstNameField = new JTextField();
        firstNameField.setBounds(180, 30, 250, 25);
        firstNameField.setBackground(new Color(224, 235, 255));
        add(firstNameField);

        // Last Name
        JLabel lastNameLabel = new JLabel("Last Name:");
        lastNameLabel.setBounds(50, 70, 120, 25);
        lastNameLabel.setForeground(new Color(0, 102, 204));
        add(lastNameLabel);

        lastNameField = new JTextField();
        lastNameField.setBounds(180, 70, 250, 25);
        lastNameField.setBackground(new Color(224, 235, 255));
        add(lastNameField);

        // Username
        JLabel userLabel = new JLabel("Username:");
        userLabel.setBounds(50, 110, 120, 25);
        userLabel.setForeground(new Color(0, 102, 204));
        add(userLabel);

        userTextField = new JTextField();
        userTextField.setBounds(180, 110, 250, 25);
        userTextField.setBackground(new Color(224, 235, 255));
        add(userTextField);

        // Password
        JLabel passwordLabel = new JLabel("Password:");
        passwordLabel.setBounds(50, 150, 120, 25);
        passwordLabel.setForeground(new Color(0, 102, 204));
        add(passwordLabel);

        passwordField = new JPasswordField();
        passwordField.setBounds(180, 150, 250, 25);
        passwordField.setBackground(new Color(224, 235, 255));
        add(passwordField);

        // Confirm Password
        JLabel confirmPasswordLabel = new JLabel("Confirm Password:");
        confirmPasswordLabel.setBounds(50, 190, 120, 25);
        confirmPasswordLabel.setForeground(new Color(0, 102, 204));
        add(confirmPasswordLabel);

        confirmPasswordField = new JPasswordField();
        confirmPasswordField.setBounds(180, 190, 250, 25);
        confirmPasswordField.setBackground(new Color(224, 235, 255));
        add(confirmPasswordField);

        // Phone Number
        JLabel phoneLabel = new JLabel("Phone Number:");
        phoneLabel.setBounds(50, 230, 120, 25);
        phoneLabel.setForeground(new Color(0, 102, 204));
        add(phoneLabel);

        phoneField = new JTextField();
        phoneField.setBounds(180, 230, 250, 25);
        phoneField.setBackground(new Color(224, 235, 255));
        phoneField.setToolTipText("Format: +27XXXXXXXXX");
        add(phoneField);

        // Register Button
        registerButton = new JButton("Register");
        registerButton.setBounds(180, 280, 120, 35);
        registerButton.setBackground(new Color(0, 102, 204));
        registerButton.setForeground(Color.WHITE);
        registerButton.setFocusPainted(false);
        add(registerButton);

        // Message Label
        messageLabel = new JLabel("");
        messageLabel.setBounds(50, 320, 400, 25);
        messageLabel.setForeground(Color.RED);
        add(messageLabel);

        // Register button action
        registerButton.addActionListener((ActionEvent e) -> registerAction());
    }

    private void registerAction() {
        String firstName = firstNameField.getText().trim();
        String lastName = lastNameField.getText().trim();
        String username = userTextField.getText().trim();
        String password = new String(passwordField.getPassword());
        String confirmPassword = new String(confirmPasswordField.getPassword());
        String phone = phoneField.getText().trim();

        // Check all fields filled
        if (firstName.isEmpty() || lastName.isEmpty() || username.isEmpty() || password.isEmpty() || confirmPassword.isEmpty() || phone.isEmpty()) {
            setMessage("Please fill in all fields.", Color.ORANGE);
            return;
        }

        // Username validation: <=5 chars and contains underscore
        if (username.length() > 5 || !username.contains("_")) {
            setMessage("Username must be 5 or fewer characters and include an underscore (_).", Color.RED);
            return;
        }

        // Password match check
        if (!password.equals(confirmPassword)) {
            setMessage("Passwords do not match.", Color.RED);
            return;
        }

        // Password complexity check
        if (!isValidPassword(password)) {
            setMessage("<html>Password must be at least 8 characters and include uppercase,<br>lowercase, number, and special character.</html>", Color.RED);
            return;
        }

        // Phone number validation: starts with +27 and 9 digits after
        if (!phone.matches("^\\+27\\d{9}$")) {
            setMessage("Phone number must start with +27 followed by 9 digits.", Color.RED);
            return;
        }

        // Check if username already exists
        if (userDatabase.containsKey(username)) {
            setMessage("Username already exists. Choose another.", Color.RED);
            return;
        }

        // Save user
        userDatabase.put(username, password);

        setMessage("Registration successful!", new Color(0, 153, 0));
        clearFields();
    }

    private void setMessage(String message, Color color) {
        messageLabel.setText(message);
        messageLabel.setForeground(color);
    }

    private void clearFields() {
        firstNameField.setText("");
        lastNameField.setText("");
        userTextField.setText("");
        passwordField.setText("");
        confirmPasswordField.setText("");
        phoneField.setText("");
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 8) {
            return false;
        }

        Pattern upperCase = Pattern.compile("[A-Z]");
        Pattern lowerCase = Pattern.compile("[a-z]");
        Pattern digit = Pattern.compile("[0-9]");
        Pattern specialChar = Pattern.compile("[^a-zA-Z0-9]");

        return upperCase.matcher(password).find()
                && lowerCase.matcher(password).find()
                && digit.matcher(password).find()
                && specialChar.matcher(password).find();
    }
}
