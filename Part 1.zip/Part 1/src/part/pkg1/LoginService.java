package part.pkg1;

import part.pkg1.User;
import java.util.HashMap;
import java.util.regex.Pattern;

public class LoginService {

    private final HashMap<String, User> userDatabase = new HashMap<>();

    /**
     * Registers a new user.
     * @param firstName
     * @param lastName
     * @param username
     * @param password
     * @param confirmPassword
     * @param phone
     * @return null if success, or error message string if failure.
     */
    public String registerUser(String firstName, String lastName, String username, String password, String confirmPassword, String phone) {
        if (isEmpty(firstName) || isEmpty(lastName) || isEmpty(username) || isEmpty(password) || isEmpty(confirmPassword) || isEmpty(phone)) {
            return "Please fill in all fields.";
        }

        if (!isValidUsername(username)) {
            return "Username must be 5 or fewer characters and include an underscore (_).";
        }

        if (!password.equals(confirmPassword)) {
            return "Passwords do not match.";
        }

        if (!isValidPassword(password)) {
            return "Password must be at least 8 characters and include uppercase, lowercase, number, and special character.";
        }

        if (!phone.matches("^\\+27\\d{9}$")) {
            return "Phone number must start with +27 followed by 9 digits.";
        }

        if (userDatabase.containsKey(username)) {
            return "Username already exists. Choose another.";
        }

        User newUser = new User(firstName, lastName, username, password, phone);
        userDatabase.put(username, newUser);
        return null; // success
    }

    /**
     * Attempts to login a user.
     * @param username
     * @param password
     * @return null if success, or error message string if failure.
     */
    public String loginUser(String username, String password) {
        if (isEmpty(username) || isEmpty(password)) {
            return "Please enter username and password.";
        }

        if (!isValidUsername(username)) {
            return "Invalid username format.";
        }

        User user = userDatabase.get(username);
        if (user != null && user.getPassword().equals(password)) {
            return null; // success
        } else {
            return "Invalid username or password.";
        }
    }

    // Helper methods

    private boolean isEmpty(String s) {
        return s == null || s.trim().isEmpty();
    }

    private boolean isValidPassword(String password) {
        if (password.length() < 8) return false;

        Pattern upperCase = Pattern.compile("[A-Z]");
        Pattern lowerCase = Pattern.compile("[a-z]");
        Pattern digit = Pattern.compile("[0-9]");
        Pattern specialChar = Pattern.compile("[^a-zA-Z0-9]");

        return upperCase.matcher(password).find() &&
               lowerCase.matcher(password).find() &&
               digit.matcher(password).find() &&
               specialChar.matcher(password).find();
    }

    private boolean isValidUsername(String username) {
        return username.length() <= 5 && username.contains("_");
    }

    // For testing or admin purposes: clear all users
    public void clearUsers() {
        userDatabase.clear();
    }

    // For testing or admin purposes: get user count
    public int getUserCount() {
        return userDatabase.size();
    }
}
