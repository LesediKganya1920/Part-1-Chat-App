
/**
 * This class demonstrates a User class with common Java errors and their corrections
 */
public class UserDemo {
    
    // The User class from the question (with no errors)
    public static class User {
        private final String firstName;
        private final String lastName;
        private final String username;
        private final String password;
        private final String phone;

        public User(String firstName, String lastName, String username, String password, String phone) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.phone = phone;
        }

        // Getters (no setters for immutability)
        public String getFirstName() { return firstName; }
        public String getLastName() { return lastName; }
        public String getUsername() { return username; }
        public String getPassword() { return password; }
        public String getPhone() { return phone; }
        
        /**
         *
         * @return
         */
        @Override
        public String toString() {
            return "User{" + "firstName=" + firstName + ", lastName=" + lastName + 
                   ", username=" + username + ", password=" + password + ", phone=" + phone + '}';
        }
    }
    
    // Class with intentional errors to demonstrate common mistakes
    public static class UserWithErrors {
        /*
        // ERROR 1: Missing access modifier (will default to package-private)
        String firstName;  
        
        // ERROR 2: Using 'final' without initialization
        final String lastName;  
        
        // ERROR 3: Using incorrect data type
        int username;  
        
        // ERROR 4: Not following Java naming conventions
        String user_password;  
        
        // ERROR 5: Missing semicolon
        String phone  
        */
        
        // CORRECTED VERSION:
        private final String firstName;
        private final String lastName;
        private final String username;
        private final String password;
        private final String phone;
        
        // ERROR 6: Constructor with wrong parameter names
        /*
        public UserWithErrors(String first, String last, String user, String pass, String tel) {
            firstName = first;  // This is actually correct
            lastName = last;    // This is correct too
            username = user;    // Correct
            password = pass;    // Correct
            phone = tel;        // Correct but less readable
        }
        */
        
        // CORRECTED VERSION (better practice):
        public UserWithErrors(String firstName, String lastName, String username, String password, String phone) {
            this.firstName = firstName;
            this.lastName = lastName;
            this.username = username;
            this.password = password;
            this.phone = phone;
        }
        
        // ERROR 7: Missing getters and setters for private fields
        // We should provide getters for all fields
        
        public String getFirstName() { 
            // ERROR 8: Returning wrong value
            // return lastName;  // WRONG
            return firstName;  // CORRECT
        }
        
        public String getLastName() { return lastName; }
        public String getUsername() { return username; }
        public String getPassword() { return password; }
        public String getPhone() { return phone; }
        
        // ERROR 9: Not overriding toString() properly
        /*
        public String toString() {
            return firstName + " " + lastName;  // Missing important information
        }
        */
        
        // CORRECTED toString():
        @Override
        public String toString() {
            return "UserWithErrors{" + "firstName=" + firstName + ", lastName=" + lastName + 
                   ", username=" + username + ", password=" + password + ", phone=" + phone + '}';
        }
    }
    
    public static void main(String[] args) {
        System.out.println("=== Java Code Error Correction Demo ===\n");
        
        // Create a proper User object (from the correct class)
        User user1 = new User("John", "Doe", "johndoe", "secret123", "555-1234");
        System.out.println("Correct User object created:");
        System.out.println(user1);
        System.out.println();
        
        // Create a UserWithErrors object (from the class with intentional errors)
        UserWithErrors user2 = new UserWithErrors("Jane", "Smith", "janesmith", "password456", "555-5678");
        System.out.println("UserWithErrors object created:");
        System.out.println(user2);
        System.out.println();
        
        // Demonstrate common errors in practice
        System.out.println("=== Common Java Errors and Solutions ===\n");
        
        // ERROR EXAMPLE 1: NullPointerException
        System.out.println("1. NullPointerException:");
        try {
            // This will cause a NullPointerException
            // System.out.println(nullString.length());
            System.out.println("   Error: Calling method on null reference");
        } catch (Exception e) {
            System.out.println("   Solution: Add null check - if(nullString != null) {...}");
        }
        
        // ERROR EXAMPLE 2: ArrayIndexOutOfBoundsException
        System.out.println("2. ArrayIndexOutOfBoundsException:");
        try {
            // This will cause an ArrayIndexOutOfBoundsException
            // System.out.println(numbers[5]);
            System.out.println("   Error: Accessing array element beyond its size");
        } catch (Exception e) {
            System.out.println("   Solution: Check array length before access - if(index < numbers.length) {...}");
        }
        
        // ERROR EXAMPLE 3: Logical errors
        System.out.println("3. Logical Errors:");
        int a = 5;
        int b = 10;
        // This has a logical error (wrong operator)
        int incorrectSum = a * b;  // Should be a + b
        System.out.println("   Error: Using wrong operator (a * b = " + incorrectSum + ")");
        System.out.println("   Solution: Use correct operator (a + b = " + (a + b) + ")");
        
        // ERROR EXAMPLE 4: Incorrect loop condition
        System.out.println("4. Loop Condition Errors:");
        System.out.println("   Error: for(int i = 0; i <= 5; i++) when you have 5 elements (0-4)");
        System.out.println("   Solution: Use for(int i = 0; i < 5; i++) instead");
        
        // ERROR EXAMPLE 5: Case sensitivity
        System.out.println("5. Case Sensitivity:");
        // This will not work because of case sensitivity
        // if (name.equals("JAVA")) { // false
        System.out.println("   Error: Case-sensitive string comparison without considering case");
        System.out.println("   Solution: Use name.equalsIgnoreCase(\"JAVA\")");
        
        System.out.println("\n=== NetBeans Tips ===");
        System.out.println("1. Use Alt+Enter for quick fixes");
        System.out.println("2. Look for red underline for syntax errors");
        System.out.println("3. Use yellow bulbs for code suggestions");
        System.out.println("4. Run your code frequently to catch errors early");
        System.out.println("5. Use the debugger to step through your code");
    }
}